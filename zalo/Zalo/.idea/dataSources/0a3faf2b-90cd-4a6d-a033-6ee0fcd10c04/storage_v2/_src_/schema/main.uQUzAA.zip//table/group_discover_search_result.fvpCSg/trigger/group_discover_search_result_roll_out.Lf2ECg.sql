CREATE TRIGGER group_discover_search_result_roll_out  AFTER INSERT ON group_discover_search_result WHEN 100 < (SELECT count(*) FROM group_discover_search_result)  BEGIN  DELETE FROM group_discover_search_result WHERE id =  (SELECT id FROM group_discover_search_result LIMIT 1);  END;

