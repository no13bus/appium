CREATE TRIGGER delete_old_search_result  AFTER INSERT ON media_search_result WHEN 100 < (SELECT count(*) FROM media_search_result)  BEGIN  DELETE FROM media_search_result WHERE keyword =  (SELECT keyword FROM media_search_result LIMIT 1);  END;

