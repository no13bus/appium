CREATE TRIGGER delete_old_suggest_sticker  AFTER INSERT ON sticker_suggest_result WHEN 500 < (SELECT count(*) FROM sticker_suggest_result)  BEGIN  DELETE FROM sticker_suggest_result WHERE keyword =  (SELECT keyword FROM sticker_suggest_result LIMIT 1);  END;

