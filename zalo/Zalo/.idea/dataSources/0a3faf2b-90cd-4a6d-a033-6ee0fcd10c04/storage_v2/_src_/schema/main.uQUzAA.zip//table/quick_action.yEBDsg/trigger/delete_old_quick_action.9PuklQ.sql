CREATE TRIGGER delete_old_quick_action  AFTER INSERT ON quick_action WHEN 100 < (SELECT count(*) FROM quick_action)  BEGIN  DELETE FROM quick_action WHERE keyword =  (SELECT keyword FROM quick_action LIMIT 1);  END;

